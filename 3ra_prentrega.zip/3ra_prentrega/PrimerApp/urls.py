from django.urls import path
from PrimerApp import views

urlpatterns = [
    path ('productos/', views.lista_producto, name='productos'),
    path ('productoformulario/', views.productoformulario, name='formulario'),

]