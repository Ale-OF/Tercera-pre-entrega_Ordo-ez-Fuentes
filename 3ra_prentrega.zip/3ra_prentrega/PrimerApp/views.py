from django.shortcuts import render
from PrimerApp.models import Producto
from django.http import HttpResponse

def lista_producto(request):
    productos = Producto.objects.all()  
    return render(request, 'lista_productos.html')

def productoformulario(request):
    return render(request,'PrimerApp/productoformulario.html')