from django.http import HttpResponse
from django.shortcuts import render
from PrimerApp.models import Producto


def saludo (request):
    return HttpResponse ("Bienvenidx!")

def lista_producto(request):
    productos = Producto.objects.all()  
    return render(request, 'lista_productos.html', {'productos': productos})